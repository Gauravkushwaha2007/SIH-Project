import { resolve, dirname } from 'node:path';
import { existsSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Auto load .env if not already set
if (!process.env.GEMINI_API_KEY) {
  const envCandidates = [
    resolve(process.cwd(), '.env'),
    resolve(process.cwd(), 'server/.env'),
    resolve(__dirname, '.env'),
    resolve(__dirname, '../.env'),
  ];
  for (const p of envCandidates) {
    if (existsSync(p)) {
      try {
        const text = readFileSync(p, 'utf8');
        for (const line of text.split(/\r?\n/)) {
          const t = line.trim();
          if (!t || t.startsWith('#')) continue;
          const idx = t.indexOf('=');
          if (idx > 0) {
            const k = t.slice(0, idx).trim();
            const v = t.slice(idx + 1).trim();
            if (!process.env[k]) process.env[k] = v;
          }
        }
      } catch {}
    }
  }
}

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models';

function cleanText(value, max = 6000) {
  return String(value ?? '').replace(/\u0000/g, '').slice(0, max);
}

export function aiConfigured() {
  return Boolean(process.env.GEMINI_API_KEY);
}

export async function askForecastAI({ message, context = {}, language = 'en' }) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    return {
      configured: false,
      reply: 'AI API key is not configured. Please set GEMINI_API_KEY in the server .env file and restart.',
    };
  }

  // Model priority cascade: try configured model, then proven working models
  const candidateModels = Array.from(
    new Set([
      process.env.GEMINI_MODEL,
      'gemini-3.5-flash',
      'gemini-3.5-flash-lite',
      'gemini-flash-lite-latest',
      'gemini-3.8-flash',
    ].filter(Boolean))
  );

  const prompt = `You are ForecastGuard AI (Mausam Intelligence), an AI weather forecast reliability assistant for Indian medium-range forecasts (SIH26079).

RULES:
- Always answer in easy, simple, crystal-clear English.
- Avoid unnecessarily dense academic jargon. Explain weather and statistical concepts in plain everyday language that anyone can understand.
- Use ONLY the supplied forecast context for project-specific numbers. Never invent a temperature, rainfall amount, probability, location risk, observation, or model metric.
- Clearly note when the data is demo/simulated or if a requested fact is not present in the current feed.
- You are an explanation assistant. The project's ML forecast-risk model computed the bust probability and confidence; your role is to explain what it means simply.
- Structure answers clearly with short paragraphs and bullet points where helpful.
- If asked about a city or location not in the regional forecast, point them to the local weather search bar.
- If the user asks how the model works, explain simply: past forecast errors + current weather patterns -> bust risk probability -> reliability score.

User question: ${cleanText(message, 1200)}

CURRENT PROJECT CONTEXT:
${JSON.stringify(context, null, 2)}`;

  let lastError = null;

  for (const model of candidateModels) {
    try {
      const response = await fetch(
        `${GEMINI_URL}/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.25, maxOutputTokens: 800 },
          }),
        }
      );

      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const detail = data?.error?.message || `Model ${model} returned ${response.status}`;
        lastError = new Error(detail);
        // If 404 (model retired/unavailable) or 503 (high demand), try next model
        continue;
      }

      const reply = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('').trim();
      if (!reply) {
        lastError = new Error(`Model ${model} returned an empty response.`);
        continue;
      }

      return { configured: true, model, reply };
    } catch (err) {
      lastError = err;
    }
  }

  throw lastError || new Error('Failed to generate AI response from available models.');
}

export async function api(path, options = {}) {
  const { method = 'GET', body } = options;
  try {
    const r = await fetch(`/api${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const type = r.headers.get('content-type') || '';
    if (!type.includes('application/json')) throw new Error('Backend response unavailable. Start the project with npm run dev.');
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || 'Request failed');
    return data;
  } catch (error) {
    if (error instanceof TypeError) throw new Error('Cannot reach the forecast API. Start the project with npm run dev.');
    throw error;
  }
}

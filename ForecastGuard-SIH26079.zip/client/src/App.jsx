import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowRight, BrainCircuit, CalendarDays, Check,
  ChevronDown, Cloud, CloudDrizzle, CloudLightning, CloudRain, CloudSun,
  Eye, Gauge, History, Layers, LocateFixed, MapPin, Menu, Mic, MicOff, RefreshCw,
  Search, Send, ShieldCheck, Sparkles, Sun, Thermometer, Wind, X
} from 'lucide-react';
import L from 'leaflet';
import { api } from './api';

const pct = (v) => `${(Number(v || 0) * 100).toFixed(0)}%`;
const varLabel = {
  rainfall: 'Rainfall',
  temperature: 'Temperature',
  wind: 'Wind Speed',
  pressure: 'Surface Pressure',
};
const weatherLabel = (code) => {
  if (code === 0) return 'Clear Sky';
  if ([1, 2].includes(code)) return 'Partly Cloudy';
  if (code === 3) return 'Overcast Clouds';
  if ([45, 48].includes(code)) return 'Fog & Mist';
  if ([51, 53, 55, 56, 57].includes(code)) return 'Light Drizzle';
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return 'Rain Showers';
  if ([71, 73, 75, 77, 85, 86].includes(code)) return 'Snowfall';
  if ([95, 96, 99].includes(code)) return 'Thunderstorms';
  return 'Weather Available';
};
const WeatherIcon = ({ code = 2, size = 30 }) => {
  if (code === 0) return <Sun size={size} />;
  if ([61, 63, 65, 80, 81, 82].includes(code)) return <CloudRain size={size} />;
  if ([51, 53, 55].includes(code)) return <CloudDrizzle size={size} />;
  if ([95, 96, 99].includes(code)) return <CloudLightning size={size} />;
  if ([1, 2].includes(code)) return <CloudSun size={size} />;
  return <Cloud size={size} />;
};

const NAV = [
  ['home', 'Overview', Gauge],
  ['forecast', 'Forecast Inspector', CloudRain],
  ['map', 'Live Risk Map', MapPin],
  ['history', 'Historical Accuracy', History],
  ['model', 'ML Architecture', BrainCircuit],
];

function App() {
  const [page, setPage] = useState('home');
  const [data, setData] = useState(null);
  const [detail, setDetail] = useState(null);
  const [historical, setHistorical] = useState(null);
  const [model, setModel] = useState(null);
  const [leadDay, setLeadDay] = useState(5);
  const [variable, setVariable] = useState('rainfall');
  const [selectedRegion, setSelectedRegion] = useState('central');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [places, setPlaces] = useState([]);
  const [localWeather, setLocalWeather] = useState(null);
  const [localName, setLocalName] = useState('Your City');
  const [localLoading, setLocalLoading] = useState(false);
  const [aiHealth, setAiHealth] = useState({ configured: false });
  const [messages, setMessages] = useState([
    {
      role: 'ai',
      text: 'Hello! I am ForecastGuard AI. Ask me anything about medium-range weather forecast reliability — e.g. "Which forecast day is most unpredictable?" or "Why does Central India have elevated risk?"'
    }
  ]);
  const [aiInput, setAiInput] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef(null);

  const load = async () => {
    setLoading(true); setError('');
    try {
      const [o, h, m, ai] = await Promise.all([
        api('/weather/overview'),
        api(`/weather/historical?region=${selectedRegion}&variable=${variable}&leadDay=${leadDay}`),
        api('/weather/model'),
        api('/ai/health'),
      ]);
      setData(o); setHistorical(h); setModel(m); setAiHealth(ai);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);
  useEffect(() => {
    if (!data) return;
    Promise.all([
      api(`/weather/prediction?leadDay=${leadDay}&region=${selectedRegion}&variable=${variable}`),
      api(`/weather/historical?region=${selectedRegion}&variable=${variable}&leadDay=${leadDay}`),
    ]).then(([d, h]) => { setDetail(d); setHistorical(h); }).catch(() => {});
  }, [data, leadDay, selectedRegion, variable]);

  useEffect(() => {
    const q = search.trim();
    if (q.length < 2) { setPlaces([]); return; }
    const t = setTimeout(async () => {
      try {
        const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=6&language=en&format=json`);
        const j = await r.json(); setPlaces(j.results || []);
      } catch { setPlaces([]); }
    }, 350);
    return () => clearTimeout(t);
  }, [search]);

  const fetchLocal = async (lat, lon, name) => {
    setLocalLoading(true);
    try {
      const w = await api(`/local-weather?lat=${lat}&lon=${lon}`);
      setLocalWeather(w);
      setLocalName(name || 'Your Location');
    } catch {
      setLocalWeather(null);
    } finally {
      setLocalLoading(false);
    }
  };

  const useLocation = () => {
    if (!navigator.geolocation) return;
    setLocalLoading(true);
    navigator.geolocation.getCurrentPosition(
      (p) => fetchLocal(p.coords.latitude, p.coords.longitude, 'Current Location'),
      () => setLocalLoading(false),
      { enableHighAccuracy: false, timeout: 8000 }
    );
  };

  const selectPlace = (p) => {
    setSearch('');
    setPlaces([]);
    fetchLocal(
      p.latitude,
      p.longitude,
      [p.name, p.admin1, p.country].filter(Boolean).join(', ')
    );
  };

  const context = useMemo(
    () => ({
      project: 'SIH26079 ForecastGuard Weather Bust Intelligence',
      dataMode: data?.dataset?.mode || 'demo',
      currentRun: data?.currentRun,
      selected: detail
        ? {
            region: detail.regionName,
            leadDay: detail.leadDay,
            variable: detail.variable,
            forecastValue: detail.forecastValue,
            bustProbability: detail.bustProbability,
            confidence: detail.confidence,
            riskLevel: detail.riskLevel,
            historicalErrorFrequency: detail.historicalErrorFrequency,
            weatherRegime: detail.weatherRegime,
            explanation: detail.explanation,
          }
        : null,
      overview: data?.kpis,
      localWeather: localWeather?.current
        ? {
            place: localName,
            temperature: localWeather.current.temperature_2m,
            apparentTemperature: localWeather.current.apparent_temperature,
            precipitation: localWeather.current.precipitation,
            wind: localWeather.current.wind_speed_10m,
            weather: weatherLabel(localWeather.current.weather_code),
          }
        : null,
    }),
    [data, detail, localWeather, localName]
  );

  const speak = (text) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const clean = text.replace(/[*_#]/g, '');
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = 'en-US';
    const voices = window.speechSynthesis.getVoices();
    u.voice =
      voices.find((v) => v.lang.startsWith('en')) ||
      voices.find((v) => v.lang.includes('en')) ||
      null;
    window.speechSynthesis.speak(u);
  };

  const askAI = async (text = aiInput) => {
    const q = text.trim();
    if (!q || aiBusy) return;
    setAiInput('');
    setMessages((m) => [...m, { role: 'user', text: q }]);
    setAiBusy(true);
    try {
      const r = await api('/ai/chat', {
        method: 'POST',
        body: { message: q, context, language: 'en' },
      });
      setMessages((m) => [...m, { role: 'ai', text: r.reply }]);
      speak(r.reply);
    } catch (e) {
      setMessages((m) => [
        ...m,
        {
          role: 'ai',
          text: e.message || 'Unable to connect to the AI model. Please verify API configuration.',
        },
      ]);
    } finally {
      setAiBusy(false);
    }
  };

  const startVoice = () => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setMessages((m) => [
        ...m,
        {
          role: 'ai',
          text: 'Voice recognition is not supported in this browser. Please use Chrome or Edge.',
        },
      ]);
      return;
    }
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const r = new SpeechRecognition();
    r.lang = 'en-US';
    r.interimResults = false;
    r.maxAlternatives = 1;
    r.onstart = () => setListening(true);
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    r.onresult = (e) => {
      const text = e.results[0][0].transcript;
      setAiInput(text);
      askAI(text);
    };
    recognitionRef.current = r;
    r.start();
  };

  if (loading)
    return (
      <div className="loading-screen">
        <div className="weather-orb">
          <CloudRain size={36} />
        </div>
        <h1>ForecastGuard</h1>
        <p>Loading meteorological engine & forecast intelligence…</p>
      </div>
    );

  if (error)
    return (
      <div className="loading-screen">
        <AlertTriangle size={48} color="#ef4444" />
        <h2>Data Engine Unavailable</h2>
        <p>{error}</p>
        <button className="primary" onClick={load}>
          <RefreshCw size={16} /> Retry Connection
        </button>
      </div>
    );

  const regions = data?.regions || [];
  const selected = regions.find((r) => r.region === selectedRegion) || regions[0];
  const riskColor = (p) => (p >= 0.5 ? 'danger' : p >= 0.25 ? 'warn' : 'safe');

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-icon">
            <CloudRain size={24} />
          </div>
          <div>
            <b>
              Forecast<span>Guard</span>
            </b>
            <small>SIH26079 · Weather Reliability</small>
          </div>
        </div>

        <div className="search-wrap">
          <Search size={18} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search Indian cities — Bhopal, Indore, Delhi, Mumbai, Bengaluru…"
          />
          {places.length > 0 && (
            <div className="search-results">
              {places.map((p) => (
                <button
                  key={`${p.id}-${p.latitude}`}
                  onClick={() => selectPlace(p)}
                >
                  <MapPin size={15} />
                  <span>
                    <b>{p.name}</b>
                    <small>
                      {[p.admin1, p.country].filter(Boolean).join(', ')}
                    </small>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="top-right">
          <button className="location-btn" onClick={useLocation}>
            <LocateFixed size={16} /> My Location
          </button>
          <button className="ai-top-btn" onClick={() => setPage('home')}>
            <Sparkles size={16} /> Forecast AI
          </button>
        </div>
      </header>

      <div className="layout">
        <aside className="sidebar">
          <nav>
            {NAV.map(([id, label, Icon]) => (
              <button
                key={id}
                className={page === id ? 'active' : ''}
                onClick={() => setPage(id)}
              >
                <Icon size={18} />
                <span>{label}</span>
                {page === id && <Check size={14} />}
              </button>
            ))}
          </nav>

          <div className="side-note">
            <ShieldCheck size={20} />
            <div>
              <b>What is a Forecast Bust?</b>
              <span>
                A severe mismatch between medium-range model predictions and real
                atmospheric ground truth.
              </span>
            </div>
          </div>
          <div className="side-bottom">
            <span className="dot" /> Demo Simulation Engine
          </div>
        </aside>

        <main className="content">
          <section className="hero">
            <div>
              <span className="eyebrow">Operational Reliability Check</span>
              <h1>How much can you trust today's weather forecast?</h1>
              <p>
                Track Days 1 through 10 to detect where numerical models are
                likely to experience major forecast busts across India.
              </p>
            </div>
            <div className="hero-weather">
              <CloudSun size={52} />
              <div>
                <span>National Cycle</span>
                <strong>{data?.currentRun?.initialization ? '00Z' : 'Active'}</strong>
                <small>Numerical Forecast Run</small>
              </div>
            </div>
          </section>

          <section className="quick-grid">
            <div className="local-card card">
              <div className="card-title">
                <span>
                  <MapPin size={16} /> Local Weather Near You
                </span>
                <button onClick={useLocation} title="Refresh Location">
                  <RefreshCw size={14} />
                </button>
              </div>
              {localWeather?.current ? (
                <div className="local-main">
                  <WeatherIcon
                    code={localWeather.current.weather_code}
                    size={42}
                  />
                  <div>
                    <b>
                      {Math.round(localWeather.current.temperature_2m)}°C
                    </b>
                    <span>{localName}</span>
                    <small>
                      {weatherLabel(localWeather.current.weather_code)} · Feels like{' '}
                      {Math.round(localWeather.current.apparent_temperature)}°C
                    </small>
                  </div>
                  <div className="local-meta">
                    <span>
                      <Wind size={13} />{' '}
                      {Math.round(localWeather.current.wind_speed_10m)} km/h
                    </span>
                    <span>
                      <CloudRain size={13} />{' '}
                      {localWeather.current.precipitation} mm
                    </span>
                  </div>
                </div>
              ) : (
                <div className="local-empty">
                  <MapPin size={24} />
                  <span>
                    {localLoading
                      ? 'Fetching local weather…'
                      : 'Search a city above or tap "My Location"'}
                  </span>
                </div>
              )}
            </div>

            <div className="kpi card">
              <span>Overall Reliability</span>
              <strong>{pct(data?.kpis?.overallConfidence)}</strong>
              <small>Average confidence across Day 1–10</small>
            </div>

            <div className="kpi card">
              <span>Most Uncertain Day</span>
              <strong>Day {data?.kpis?.mostUncertainLeadDay}</strong>
              <small>Lowest model confidence point</small>
            </div>

            <div className="kpi card danger-card">
              <span>Peak Bust Risk</span>
              <strong>{pct(data?.kpis?.maxBustProbability)}</strong>
              <small>Highest probability in current run</small>
            </div>
          </section>

          <section className="ai-feature card">
            <div className="ai-feature-head">
              <div className="ai-avatar">
                <Sparkles size={22} />
              </div>
              <div>
                <span className="eyebrow">AI WEATHER COPILOT</span>
                <h2>Ask ForecastGuard AI</h2>
                <p>
                  Get clear explanations about forecast risks, uncertainty, and
                  weather regimes in simple English.
                </p>
              </div>
              <div className={`ai-status ${aiHealth.configured ? 'on' : ''}`}>
                <i /> {aiHealth.configured ? 'Gemini AI Online' : 'Key Configured'}
              </div>
            </div>

            <div className="suggestions">
              {[
                'Which forecast day is most unpredictable?',
                'Why does Central India have elevated risk?',
                'Explain Day 5 rainfall forecast',
                'How does the bust detection model work?',
              ].map((q) => (
                <button key={q} onClick={() => askAI(q)}>
                  {q}
                  <ArrowRight size={13} />
                </button>
              ))}
            </div>

            <div className="ai-input-row">
              <button
                className={`voice-btn ${listening ? 'listening' : ''}`}
                onClick={startVoice}
                title="Speak question in English"
              >
                {listening ? <MicOff size={19} /> : <Mic size={19} />}
              </button>
              <input
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && askAI()}
                placeholder="Ask anything — e.g., Where is the rainfall forecast least reliable this week?"
              />
              <button
                className="send-btn"
                onClick={() => askAI()}
                disabled={aiBusy}
              >
                <Send size={18} />
              </button>
            </div>

            {messages.length > 1 && (
              <div className="ai-mini-answer">
                <div className="ai-avatar small">
                  <Sparkles size={16} />
                </div>
                <div>
                  <b>ForecastGuard AI</b>
                  <p>{messages[messages.length - 1].text}</p>
                </div>
              </div>
            )}
          </section>

          {page === 'home' && (
            <Home
              data={data}
              regions={regions}
              leadDay={leadDay}
              setLeadDay={setLeadDay}
              selected={selected}
              selectedRegion={selectedRegion}
              setSelectedRegion={setSelectedRegion}
              setPage={setPage}
              riskColor={riskColor}
            />
          )}

          {page === 'forecast' && (
            <Forecast
              data={data}
              detail={detail}
              leadDay={leadDay}
              setLeadDay={setLeadDay}
              variable={variable}
              setVariable={setVariable}
              selected={selected}
              selectedRegion={selectedRegion}
              setSelectedRegion={setSelectedRegion}
              riskColor={riskColor}
            />
          )}

          {page === 'map' && (
            <RiskMap
              data={data}
              regions={regions}
              leadDay={leadDay}
              setLeadDay={setLeadDay}
              selectedRegion={selectedRegion}
              setSelectedRegion={setSelectedRegion}
              setPage={setPage}
              riskColor={riskColor}
            />
          )}

          {page === 'history' && (
            <HistoryPage historical={historical} data={data} />
          )}

          {page === 'model' && <ModelPage model={model} />}
        </main>
      </div>
    </div>
  );
}

function Home({
  data,
  regions,
  leadDay,
  setLeadDay,
  selected,
  selectedRegion,
  setSelectedRegion,
  setPage,
  riskColor,
}) {
  const timeline = data?.timeline || [];
  return (
    <>
      <section className="section-head">
        <div>
          <span className="eyebrow">Forecast Reliability Curve</span>
          <h2>Day 1 → Day 10 Outlook</h2>
          <p>Confidence drops and bust risk increases with lead time.</p>
        </div>
        <button className="link-btn" onClick={() => setPage('forecast')}>
          Open Detailed Inspector <ArrowRight size={15} />
        </button>
      </section>

      <div className="day-strip">
        {timeline.map((d) => (
          <button
            key={d.leadDay}
            className={leadDay === d.leadDay ? 'selected' : ''}
            onClick={() => setLeadDay(d.leadDay)}
          >
            <span>Day {d.leadDay}</span>
            <strong>{pct(d.confidence)}</strong>
            <small className={riskColor(d.bustProbability)}>
              {pct(d.bustProbability)} risk
            </small>
          </button>
        ))}
      </div>

      <section className="two-col">
        <div className="card">
          <div className="card-title">
            <span>
              <MapPin size={16} /> High Risk Regions
            </span>
            <button onClick={() => setPage('map')}>
              Open Map <ArrowRight size={13} />
            </button>
          </div>
          <div className="region-list">
            {regions
              .slice()
              .sort((a, b) => b.bustProbability - a.bustProbability)
              .slice(0, 5)
              .map((r) => (
                <button
                  key={r.region}
                  className="region-row"
                  onClick={() => {
                    setSelectedRegion(r.region);
                    setPage('forecast');
                  }}
                >
                  <span>
                    <b>{r.regionName}</b>
                    <small>
                      {varLabel[r.dominantVariable] || r.dominantVariable} · Day{' '}
                      {r.leadDay}
                    </small>
                  </span>
                  <strong className={riskColor(r.bustProbability)}>
                    {pct(r.bustProbability)}
                  </strong>
                  <ArrowRight size={15} />
                </button>
              ))}
          </div>
        </div>

        <div className="card selected-summary">
          <div className="card-title">
            <span>
              <Activity size={16} /> Active Region Focus
            </span>
            <span className="chip">Day {selected?.leadDay}</span>
          </div>
          <h3>{selected?.regionName}</h3>
          <div className="big-risk">
            <div>
              <span>Bust Risk</span>
              <strong className={riskColor(selected?.bustProbability)}>
                {pct(selected?.bustProbability)}
              </strong>
            </div>
            <div>
              <span>Confidence</span>
              <strong>{pct(selected?.confidence)}</strong>
            </div>
          </div>
          <p>
            {selected?.riskLevel === 'Low'
              ? 'Model indicators suggest this regional forecast is stable and consistent across ensemble members.'
              : 'Ensemble disagreement and historical error patterns indicate elevated risk of a forecast bust.'}
          </p>
          <button className="primary" onClick={() => setPage('forecast')}>
            Inspect Meteorological Drivers <ArrowRight size={15} />
          </button>
        </div>
      </section>
    </>
  );
}

function Forecast({
  data,
  detail,
  leadDay,
  setLeadDay,
  variable,
  setVariable,
  selected,
  selectedRegion,
  setSelectedRegion,
  riskColor,
}) {
  return (
    <>
      <section className="section-head">
        <div>
          <span className="eyebrow">Forecast Inspector</span>
          <h2>In-Depth Model Uncertainty Analysis</h2>
          <p>Switch lead days, weather variables, and regions to analyze reliability.</p>
        </div>
        <div className="filters">
          <select value={variable} onChange={(e) => setVariable(e.target.value)}>
            {data.variables.map((v) => (
              <option key={v.id} value={v.id}>
                {varLabel[v.id] || v.label}
              </option>
            ))}
          </select>
          <select
            value={selectedRegion}
            onChange={(e) => setSelectedRegion(e.target.value)}
          >
            {data.regions.map((r) => (
              <option key={r.region} value={r.region}>
                {r.regionName}
              </option>
            ))}
          </select>
        </div>
      </section>

      <div className="compact-days">
        {data.leadDays.map((d) => (
          <button
            key={d}
            className={d === leadDay ? 'selected' : ''}
            onClick={() => setLeadDay(d)}
          >
            Day {d}
          </button>
        ))}
      </div>

      <section className="forecast-detail card">
        <div className="detail-title">
          <div>
            <span className="eyebrow">{selected?.regionName}</span>
            <h2>
              Day {leadDay} · {varLabel[variable] || variable}
            </h2>
            <p>{detail?.weatherRegime || 'Active Weather Pattern'}</p>
          </div>
          <div className={`risk-big ${riskColor(detail?.bustProbability)}`}>
            <span>Bust Risk Probability</span>
            <strong>{pct(detail?.bustProbability)}</strong>
          </div>
        </div>

        <div className="detail-grid">
          <Metric
            label="Confidence Score"
            value={pct(detail?.confidence)}
            icon={<ShieldCheck />}
          />
          <Metric
            label="Historical Error Rate"
            value={pct(detail?.historicalErrorFrequency)}
            icon={<History />}
          />
          <Metric
            label="Forecast Value"
            value={`${detail?.forecastValue ?? '—'} ${
              data.variables.find((v) => v.id === variable)?.unit || ''
            }`}
            icon={<Activity />}
          />
          <Metric
            label="Synoptic Regime"
            value={detail?.weatherRegime || 'Standard'}
            icon={<Cloud />}
          />
        </div>

        <div className="why-box">
          <div className="why-title">
            <BrainCircuit size={19} /> Why is this forecast at risk?
          </div>
          {detail?.explanation?.meteorologicalInterpretation?.slice(0, 4).map(
            (x, i) => (
              <div className="why-row" key={i}>
                <span>{i + 1}</span>
                <p>{x.text}</p>
              </div>
            )
          ) || (
            <p>Meteorological explanation is currently being processed for this cell.</p>
          )}
        </div>
      </section>
    </>
  );
}

function Metric({ label, value, icon }) {
  return (
    <div className="metric">
      <span>
        {icon}
        {label}
      </span>
      <strong>{value}</strong>
    </div>
  );
}

/* =========================================================
   REALISTIC LEAFLET MAP OF INDIA COMPONENT
========================================================= */
function RiskMap({
  data,
  regions,
  leadDay,
  setLeadDay,
  selectedRegion,
  setSelectedRegion,
  setPage,
  riskColor,
}) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const [mapStyle, setMapStyle] = useState('voyager'); // 'voyager' | 'osm' | 'dark'

  const tileURLs = {
    voyager: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    osm: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
  };

  const tileLayerRef = useRef(null);
  const cells = useMemo(
    () => regions.filter((r) => r.leadDay === leadDay),
    [regions, leadDay]
  );

  // Initialize Leaflet map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // Center on India [latitude, longitude]
    const map = L.map(mapContainerRef.current, {
      center: [22.8, 82.5],
      zoom: 4.8,
      minZoom: 4,
      maxZoom: 9,
      zoomControl: true,
      attributionControl: false,
    });

    const tileLayer = L.tileLayer(tileURLs[mapStyle], {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    tileLayerRef.current = tileLayer;
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update tile layer when style changes
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;
    tileLayerRef.current.setUrl(tileURLs[mapStyle]);
  }, [mapStyle]);

  // Update markers when leadDay or cells change
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear old markers
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    cells.forEach((r) => {
      const riskCls = riskColor(r.bustProbability);
      const isSelected = selectedRegion === r.region;

      const markerHtml = `
        <div class="clay-marker-node ${isSelected ? 'selected' : ''}">
          <div class="clay-marker-pin ${riskCls}">
            <div class="clay-marker-pulse"></div>
          </div>
          <div class="clay-marker-badge">
            <b>${r.regionName}</b>
            <span class="${riskCls}">${pct(r.bustProbability)} Risk</span>
          </div>
        </div>
      `;

      const icon = L.divIcon({
        className: 'custom-clay-div-icon',
        html: markerHtml,
        iconSize: [90, 56],
        iconAnchor: [45, 18],
      });

      const marker = L.marker([r.lat, r.lon], { icon }).addTo(map);

      // Popup card with English content and inspector button
      const popupHtml = `
        <div class="clay-popup-card">
          <div class="clay-popup-head">
            <h4>${r.regionName}</h4>
            <span class="clay-popup-tag ${riskCls}">${pct(r.bustProbability)} Risk</span>
          </div>
          <div class="clay-popup-grid">
            <div class="clay-popup-box">
              <span>Confidence</span>
              <strong>${pct(r.confidence)}</strong>
            </div>
            <div class="clay-popup-box">
              <span>Weather Regime</span>
              <strong>${r.weatherRegime || 'Normal'}</strong>
            </div>
          </div>
          <button id="inspect-${r.region}" class="clay-popup-btn">
            Inspect Full Forecast →
          </button>
        </div>
      `;

      marker.bindPopup(popupHtml, {
        closeButton: true,
        className: 'clay-leaflet-popup',
      });

      marker.on('popupopen', () => {
        const btn = document.getElementById(`inspect-${r.region}`);
        if (btn) {
          btn.onclick = () => {
            setSelectedRegion(r.region);
            setPage('forecast');
          };
        }
      });

      marker.on('click', () => {
        setSelectedRegion(r.region);
      });

      markersRef.current.push(marker);
    });
  }, [cells, selectedRegion]);

  return (
    <>
      <section className="section-head">
        <div>
          <span className="eyebrow">Real-Time Geospatial Radar</span>
          <h2>India Forecast Bust Risk Map</h2>
          <p>
            Interactive meteorological map showing where forecast failure probability is highest across India.
          </p>
        </div>
      </section>

      <div className="map-card card">
        <div className="map-controls-top">
          <div className="day-picker">
            {data.leadDays.map((d) => (
              <button
                className={d === leadDay ? 'active' : ''}
                key={d}
                onClick={() => setLeadDay(d)}
              >
                Day {d}
              </button>
            ))}
          </div>

          <div className="map-style-toggles">
            <button
              className={mapStyle === 'voyager' ? 'active' : ''}
              onClick={() => setMapStyle('voyager')}
            >
              Voyager Topo
            </button>
            <button
              className={mapStyle === 'osm' ? 'active' : ''}
              onClick={() => setMapStyle('osm')}
            >
              Standard OSM
            </button>
            <button
              className={mapStyle === 'dark' ? 'active' : ''}
              onClick={() => setMapStyle('dark')}
            >
              Night Satellite
            </button>
          </div>
        </div>

        <div className="leaflet-container-wrap">
          <div ref={mapContainerRef} className="leaflet-map-element" />
          <div className="radar-scan-overlay" />
        </div>

        <div className="map-legend">
          <span>
            <i className="safe" /> Safe Forecast (&lt;25% risk)
          </span>
          <span>
            <i className="warn" /> Moderate Uncertainty (25%–50%)
          </span>
          <span>
            <i className="danger" /> Severe Bust Risk (&gt;50%)
          </span>
        </div>
      </div>
    </>
  );
}

function HistoryPage({ historical }) {
  const byLead = historical?.byLead || [];
  return (
    <>
      <section className="section-head">
        <div>
          <span className="eyebrow">Historical Verification</span>
          <h2>Model Error Drift Over 10-Day Horizons</h2>
          <p>
            Statistical degradation curves showing how forecast accuracy diminishes as lead time extends.
          </p>
        </div>
      </section>

      <div className="history-grid">
        {byLead.map((d) => (
          <div className="history-bar card" key={d.leadDay}>
            <span>Day {d.leadDay}</span>
            <div className="bar">
              <i
                style={{
                  width: `${Math.min(100, d.meanNormalizedError * 60)}%`,
                }}
              />
            </div>
            <strong>{d.meanNormalizedError.toFixed(2)}</strong>
            <small>{pct(d.bustRate)} bust rate</small>
          </div>
        ))}
      </div>

      <div className="card plain-note">
        <History size={24} />
        <div>
          <b>Operational Benchmark Notice</b>
          <p>
            This prototype runs on a verified chronological demo dataset without label leakage.
            In production deployment, this verification engine ingests live NCMRWF numerical feeds and IMD AWS observations.
          </p>
        </div>
      </div>
    </>
  );
}

function ModelPage({ model }) {
  const m = model?.ml || {};
  const b = model?.baseline || {};
  return (
    <>
      <section className="section-head">
        <div>
          <span className="eyebrow">Machine Learning Architecture</span>
          <h2>Predictive Bust Detection Pipeline</h2>
          <p>
            Combining atmospheric stability indices, ensemble variance, and historical error frequency.
          </p>
        </div>
      </section>

      <div className="model-grid">
        <Metric
          label="Algorithm"
          value="Calibrated Logistic Regression"
          icon={<BrainCircuit />}
        />
        <Metric
          label="Test Evaluations"
          value={model?.samples?.test ?? '—'}
          icon={<Activity />}
        />
        <Metric
          label="ML F1-Score"
          value={(m.f1 ?? 0).toFixed(2)}
          icon={<ShieldCheck />}
        />
        <Metric
          label="Baseline F1"
          value={(b.f1 ?? 0).toFixed(2)}
          icon={<Gauge />}
        />
      </div>

      <div className="card pipeline">
        <div className="pipeline-step">
          <b>1</b>
          <span>Atmospheric Features</span>
        </div>
        <ArrowRight size={18} />
        <div className="pipeline-step">
          <b>2</b>
          <span>Historical Error Patterns</span>
        </div>
        <ArrowRight size={18} />
        <div className="pipeline-step">
          <b>3</b>
          <span>ML Bust Probability</span>
        </div>
        <ArrowRight size={18} />
        <div className="pipeline-step">
          <b>4</b>
          <span>Confidence Score & Warning</span>
        </div>
      </div>

      <div className="card plain-note">
        <AlertTriangle size={24} color="#f59e0b" />
        <div>
          <b>Demonstrator Prototype Scope</b>
          <p>
            Currently connected to Open-Meteo local ground feeds and deterministic medium-range test data.
            Model training is isolated chronologically to prevent lookahead bias.
          </p>
        </div>
      </div>
    </>
  );
}

export default App;
